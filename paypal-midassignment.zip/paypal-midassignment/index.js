//jshint esversion:6
const express=require("express");
const bodyParser=require("body-parser");
const app = express();
app.use(bodyParser.urlencoded({extended:true}));
const pug = require('pug');
const _ = require('lodash');

app.set('view engine', 'pug')


app.set()
var listOfCourses=[];
var registrations = {
  //key as course id, value []
}

app.get("/",function(req,res){
    //username
   // render to home // chkP 1
    res.render("index");
});

app.get("/courses/:type/:username",function(req,res){
    let type = req.params.type;
    let  username = req.params.username;
    if(type === "student"){
      res.render('home',studentPage(username));
    }else{
      res.render('home',facultyPage());
    }
});

app.get("/course/:type/:courseName/:username",(req,res) => {
    let type = req.params.type;
    let name = req.params.courseName;
    let username = req.params.username;
    console.log(name);

    let result = _.filter(listOfCourses,{courseName: name});
    console.log(result);
    if(result.length > 0){
        if(type === "student"){
          res.render("course",{ 'course':result[0],'isStudent':true, 'username': username });
      }else{
          res.render("course",{ 'course':result[0]})
      }
    }else{
        res.redirect('/');
    }
})

app.get("/addCourse", function(req,res){
    res.render("addCourse");
})

app.post("/addCourse",function(req,res){
  console.log(req.body);
  var course=req.body.course;
  var dura=req.body.duration;
  var brnch=req.body.branch;
  var fac=req.body.faculty;
  var newcourse={
    courseName:course,
    durationTaken:dura,
    branchRelated:brnch,
    Faculty:fac,
  };
  listOfCourses.push(newcourse);
  registrations[course] = [];
  // document.getElementById("smname").value = newcourse();
  res.redirect('/courses/faculty/guest');
});


let studentPage = function(username){
  let regCourse = []
  let nonReg = []
  for(let i in listOfCourses){
    if(registrations[listOfCourses[i].courseName].indexOf(username) > -1){
      regCourse.push(listOfCourses[i]);
    }else{
      nonReg.push(listOfCourses[i]);
    }
  }
  return {regCourse,nonReg,username};
}


function facultyPage(){
  // List of all the courses
  console.log(listOfCourses);
  return {listOfCourses, isFaculty: true};
}

app.post("/course/:courseName/register/:username",(req,res) => {
    let user = req.params.username;
    let courseName = req.params.courseName;
    // register the course for the student
    if(registrations[courseName]){
       registrations[courseName] = [user];
    }else{
       registrations[courseName].push(user);
    }
    let url = "/courses/student/"+user
    res.redirect(url);
})



app.get("/*",(req,res) => {
  console.log(req.url);
  res.redirect("/");
})

app.listen(3000,function(){
  console.log("listening at the port 3000.");
});
